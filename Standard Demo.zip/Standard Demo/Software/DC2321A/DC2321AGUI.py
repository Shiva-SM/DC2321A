#============================ adjust path =====================================

import sys
import os
if __name__ == "__main__":
    here = sys.path[0]
    sys.path.insert(0, os.path.join(here, '..', '..','libs'))
    sys.path.insert(0, os.path.join(here, '..', '..','external_libs'))

#============================ verify installation =============================

from SmartMeshSDK.utils import SmsdkInstallVerifier
(goodToGo,reason) = SmsdkInstallVerifier.verifyComponents(
    [
        SmsdkInstallVerifier.PYTHON,
        SmsdkInstallVerifier.PYSERIAL,
    ]
)
if not goodToGo:
    print "Your installation does not allow this application to run:\n"
    print reason
    raw_input("Press any button to exit")
    sys.exit(1)

#============================ imports =========================================

# add the SmartMeshSDK folder to the path
import time
import struct
from   operator import eq
import Tkinter
import threading
import tkMessageBox
import copy
import motedata

import DC2321AConfigurationFrame
import DC2321AConverters
import DC2321AReportFrame

from SmartMeshSDK.utils                              import AppUtils, FormatUtils
from SmartMeshSDK.ApiDefinition                      import IpMgrDefinition
from SmartMeshSDK.ApiException                       import APIError
from dustUI                                          import dustWindow, dustFrameConnection, dustFrameText
from SmartMeshSDK.IpMgrConnectorSerial               import IpMgrConnectorSerial
from SmartMeshSDK.IpMgrConnectorMux                  import IpMgrSubscribe

#============================ defines =========================================

#===== udp port
WKP_DC2321A               = 60000

class dc2321aData(object): #A singleton that holds the data for this application
    
    #======================== singleton pattern ===============================
    
    _instance = None
    _init     = False
    
    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(dc2321aData, cls).__new__(cls, *args, **kwargs)
        return cls._instance
    
    def __init__(self):
        
        # don't re-initialize an instance (needed because singleton)
        if self._init:
            return
        self._init = True
        
        # variables
        self.dataLock       = threading.RLock()
        self.data           = {}
        self.displayedMotes = [] # an array holding a list of motedata objects that are displayed
        
        self.dc2321aGuiHandler = None # store this reference in the singleton so we can access it at any time
    
    # helper functions for the self.data dictionary
    def set(self,k,v):
        with self.dataLock:
            self.data[k] = v
    
    def get(self,k):
        with self.dataLock:
            return copy.copy(self.data[k])

    # helper functions for the displayed Motes
    def addDisplayedMote(self, mote):
        with self.dataLock:
            self.displayedMotes.append(mote)

    def editDisplayedMote(self,mote,index):
        with self.dataLock:
            self.displayedMotes[index] = mote

    def getDisplayedMote(self,index):
        with self.dataLock:
            return self.displayedMotes[index]

    def clearDisplayedMotes(self):
        with self.dataLock:
            self.displayedMotes = []

    # determine if a mote is already being displayed with a mote address of addr
    def moteDisplayed(self, addr):
        with self.dataLock:
            numDisplayedMotes = int(self.get('numDisplayedMotes'))
            for i in range(numDisplayedMotes):
                displayedAddr = self.displayedMotes[i].getAddress()
                if displayedAddr == addr:
                    return True
            return False


class dc2321a(object):
    
    def __init__(
            self,
            connector,
            disconnectedCB, 
            updateMotesCB,
        ):
        
        # store params
        self.connector                 = connector
        self.disconnectedCB            = disconnectedCB
        self.updateMotesCB             = updateMotesCB
        
        # local variables
        self.converters = DC2321AConverters.DC2321AConverters()
        
        # subscriber
        self.subscriber = IpMgrSubscribe.IpMgrSubscribe(self.connector)
        self.subscriber.start()
        self.subscriber.subscribe(
            notifTypes  =    [
                IpMgrSubscribe.IpMgrSubscribe.NOTIFDATA,
            ],

            fun =            self._notifDataCallback,
            isRlbl =         False,
        )
        self.subscriber.subscribe(
            notifTypes =     [
                IpMgrSubscribe.IpMgrSubscribe.ERROR,
                IpMgrSubscribe.IpMgrSubscribe.FINISH,
            ],
            fun =            self.disconnectedCB,
            isRlbl =         True,
        )
    
    #======================== public ==========================================
    
    # get MAC addresses of all motes on the network
    def refreshMotes(self):
        motes = []
        
        # start getMoteConfig() iteration with the 0 MAC address
        currentMac      = (0,0,0,0,0,0,0,0) 
        continueAsking  = True
        while continueAsking:
            try:
                res = self.connector.dn_getMoteConfig(currentMac,True)
            except APIError:
                continueAsking = False
            else:
                if ((not res.isAP) and (res.state in [4,])):
                    motes.append(tuple(res.macAddress))
                currentMac = res.macAddress

        # order by increasing MAC address
        motes.sort()
        
        # store in data singleton
        dc2321aData().set('motes',motes)
        self.updateMotesCB()
    
    
    def disconnect(self):
        self.connector.disconnect()
    
    # data received from mote callback
    def _notifDataCallback(self,notifName,notifParams):
        print 'Received ' + str(notifParams.data) + ' from MAC address ' + FormatUtils.formatMacString(notifParams.macAddress)
        
        # get number of motes
        numMotes = dc2321aData().get('numDisplayedMotes')
        
        # verify board type
        if notifParams.dstPort != WKP_DC2321A:
            return
        
        # board is now of the correct type, add to list of accepted motes
        motes = dc2321aData().get('motes')
        
        # only want to do anything if at least 1 mote
        if numMotes < 1:
            return
        
        # check to see that the address is associated with a displayed mote
        moteIndex = 0
        for i in range(numMotes):
            tempMote = dc2321aData().getDisplayedMote(i)
            if tuple(notifParams.macAddress) == tuple(tempMote.getAddress()): #Zacknote: tuple is a cast here...
                moteIndex = i
                break
            elif i == (numMotes - 1):
                return # if it is not displayed, then we can quit
        
        # parse the data
        try:
            parsedData = self._parseData(notifParams.data)
        except ValueError as err:
            output  = "Could not parse received data {0}".format(
                FormatUtils.formatBuffer(notifParams.data)
            )
            print output
            return
        
        tempMote = dc2321aData().getDisplayedMote(moteIndex)
        # if there is no mote yet we have nothing to do
        if tempMote == None: 
            return
        
        tempMote.setValue(parsedData)
        dc2321aData().editDisplayedMote(tempMote, moteIndex)
        
        frameData = (DC2321AConverters.dataScalers[parsedData[0]][0], parsedData[1])
        dc2321aData().dc2321aGuiHandler.reportFrames[moteIndex].updateGui(frameData)

    # parse data coming from dc2321a
    def _parseData(self,byteArray):
        returnVal = 0
        try:
            returnVal = self.converters.convertData(byteArray)
        except struct.error as err:
            print 'PARSING ERROR'
            raise ValueError(err)
        return returnVal
    

class dc2321aGui(object):
    
    def __init__(self):
        
        # local variables
        self.guiLock                = threading.Lock()
        self.apiDef                 = IpMgrDefinition.IpMgrDefinition()
        self.dc2321aHandler         = None
        self.connector              = None
        
        # initialize data singleton
        dc2321aData().set('selectedMote',   None)
        dc2321aData().set('numDisplayedMotes', 0)
        
        # create window
        self.window               = dustWindow.dustWindow(
            'DC2321A',
            self._windowCb_close,
        )
        
        # add connection Frame
        self.connectionFrame      = dustFrameConnection.dustFrameConnection(
            self.window,
            self.guiLock,
            self._connectionFrameCb_connected,
            frameName="Serial connection",
            row=0,column=0,
        )
        self.connectionFrame.apiLoaded(self.apiDef)
        self.connectionFrame.serialPortText.delete("1.0",Tkinter.END)
        self.connectionFrame.show()
        
        # add configuration frame
        self.configurationFrame   = DC2321AConfigurationFrame.DC2321AConfigurationFrame(
            self.window,
            self.guiLock,
            selectedMoteChangedCB   = self._selectedMoteChangedCB,
            displayMoteButtonCB     = self._displayMoteButtonCB,
            refreshButtonCB         = self._refreshButtonCB,
            clearMotesButtonCB      = self._clearMotesButtonCB,
            row=0,column=1,
        )
        self.configurationFrame.disableButtons()
        self.configurationFrame.show()
        
        # establish a list of report Frames, so we can keep track of them as they are added
        self.reportFrames = []
        
        # local variables
        self.userMsg         = '' # error message printed to user
    
    #======================== public ==========================================
    
    def start(self):
        # start Tkinter's main thread
        try:
            self.window.bind('<<Err>>', self._sigHandlerErr)
            self.window.mainloop()
        except SystemExit:
            sys.exit()
    
    #======================== private =========================================
    
    #===== window callback to close and shut down all operations

    # we do not want to destroy the window until we have disconnected, 
    # or else it will have nothing to disconnect from.
    def _windowCb_close(self):
        if self.dc2321aHandler:
            self.dc2321aHandler.disconnect()
        # wait until we have disconnected to quit/destroy
        if self.connector:
            while(self.connector != None):
                pass
            # below is needed to get rid of the matplotlib scripts
            self.window.quit()
            self.window.destroy()
    
    # connection frame connected callback
    def _connectionFrameCb_connected(self,connector):
        self.connector = connector

        # start a notification client
        self.dc2321aHandler = dc2321a(
            connector                  = self.connector,
            disconnectedCB             = self._connectionFrameCb_disconnected,
            updateMotesCB              = self._updateMoteList,
        )
        
        # enable cfg buttons
        self.configurationFrame.enableButtons()
        
        # load operational motes
        self._refreshButtonCB()
    
    # connection frame disconnected callback
    def _connectionFrameCb_disconnected(self,notifName,notifParams):
        if self.connector:
            # disable cfg buttons
            self.configurationFrame.disableButtons()

            # update the GUI
            self.connectionFrame.updateGuiDisconnected()

            # delete the connector
            self.connector.disconnect()
        self.connector = None
    
    # selected mote changed callback
    def _selectedMoteChangedCB(self,mote):
        dc2321aData().set('selectedMote',mote)
    
    # refresh button callback
    def _refreshButtonCB(self): 
        self.dc2321aHandler.refreshMotes()
    
    # get the list of all motes, and remove ones that are not dc2321a boards
    # set the new list as the list of availible address's
    def _updateMoteList(self):
        motes = dc2321aData().get('motes')
        self.configurationFrame.writeActionMsg('Updating Motes...')
        self.configurationFrame.refresh(motes)
    
    # add a report frame if the selected mote does not already have one
    def _displayMoteButtonCB(self):
        addr = dc2321aData().get('selectedMote')
        if addr == None:
            return
        elif dc2321aData().moteDisplayed(addr):
            self.configurationFrame.writeActionMsg('Mote Already Displayed')
        else:
            self.configurationFrame.writeActionMsg('Displaying Mote...')
            self._displayReportFrame()
    
    # clear all mote displays    
    def _clearMotesButtonCB(self):
        numdisplayedmotes = dc2321aData().get('numDisplayedMotes')
        for i in reversed(range(numdisplayedmotes)):
            frm = self.reportFrames[i]
            frm.grid_forget()
            frm.destroy()
        dc2321aData().set('numDisplayedMotes', 0)
        dc2321aData().clearDisplayedMotes()
        self.configurationFrame.writeActionMsg('Clearing Motes...')
        self.reportFrames = []
    
    # report frame
    def _displayReportFrame(self):
        macAddr = dc2321aData().get('selectedMote')
        numdisplayedmotes = dc2321aData().get('numDisplayedMotes')
        mote = motedata.moteData(macAddr, numdisplayedmotes)
        dc2321aData().set('numDisplayedMotes', numdisplayedmotes + 1)
        dc2321aData().addDisplayedMote(mote)

        # determine row and column for new report frame (only 3 per column, and each column takes up 2 rows)
        row = numdisplayedmotes % 3 + 1
        column = (numdisplayedmotes / 3) * 2

        temp = DC2321AReportFrame.DC2321AReportFrame(
            self,
            getValueCb              = lambda: self._getValue(numdisplayedmotes),
            macAddr                 = macAddr,
            frameName               = mote.getAddressString(),
            row = row, column = column,
        )
        temp.show()
        self.reportFrames.append(temp)

    # callback function to get list of current values
    def _getValue(self, i):
        tempMote = dc2321aData().getDisplayedMote(i) # gets a displayed motedata
        return tempMote.getValue() # gets the current from the displayed motedata
    
    # internal signal handler
    def _sigHandlerErr(self,args):
        tkMessageBox.showerror(title="Error",message=self.userMsg)
    
    # send data to a mote over the network
    def _sendData(self, macAddr, data):
        print '\nSending ', str(data), 'to MAC address', FormatUtils.formatMacString(macAddr)
        self.connector.dn_sendData(macAddr, 0, 60000, WKP_DC2321A, 0, data) # dn_sendData(self, macAddress, priority, srcPort, dstPort, options, data)

#============================ main ============================================

def main():
    dc2321aData().dc2321aGuiHandler = dc2321aGui()
    dc2321aData().dc2321aGuiHandler.start()

if __name__ == '__main__':
    main()

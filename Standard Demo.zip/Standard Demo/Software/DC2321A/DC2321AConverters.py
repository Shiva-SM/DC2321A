
dataScalers = (
    ('IC Status', 1, int),
    ('Supply Voltage (V)', 1000, float),
    (u'Temperature (\u00b0C)', 100, float),
    ('PRI Voltage (V)', 1000, float),
    ('PRI Current (mA)', 1000, float),
    ('PRI Charge (mC)', 1000, float),
    ('SEC Voltage (V)', 1000, float),
    ('SEC Current (mA)', 1000, float),
    ('SEC Charge (mC)', 1000, float),
    ('Time (sec)', 1000, float),
    ('Mote Charge (mA)', 1, int),
    ('ADC 0 (V)', 1000, float),
    ('ADC 1 (V)', 1000, float),
    ('ADC 2 (V)', 1000, float),
    ('ADC 3 (V)', 1000, float),
    ('I2C Data', -1, int),
    ('Increment', 1, int));

class DC2321AConverters(object):
    #======================== singleton pattern ===============================
    
    _instance           = None
    _init               = False
    
    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(DC2321AConverters,cls).__new__(cls, *args, **kwargs)
        return cls._instance
    
    def __init__(self):
        
        # don't re-initialize an instance (needed because singleton)
        if self._init:
            return
        self._init = True
        
    
    def convertData(self,byteArray):   
        '''
        \brief get the type of data sent and return the data properly scaled
        '''
        dataType = tuple(byteArray)[0]
        data = self.byteTupleToLong(byteArray[1:len(byteArray)])
        
        if(dataScalers[dataType][2] is float):
            returnData = float(data)
            dataScaler = dataScalers[dataType][1]
            returnData = returnData / dataScaler
        elif(dataScalers[dataType][2] is int):
            returnData = data
        elif(dataScalers[dataType][2] is str):
            returnData = str(data)
            
        return dataType, returnData
        
        
    def _toString(self, byteArray):
        return ''.join([chr(b) for b in byteArray])
        
    def byteTupleToLong(self, byteArray):
        return (byteArray[0] << 24) + (byteArray[1] << 16) + (byteArray[2] << 8) + byteArray[3]

#============================ main ============================================

def main():
	DC2321converter = DC2321AConverters()
	print DC2321converter.convertCharge(0x00000A)

if __name__ == '__main__':
	main()
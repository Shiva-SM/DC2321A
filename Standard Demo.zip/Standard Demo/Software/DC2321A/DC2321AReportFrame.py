#============================ adjust path =====================================

import sys
import os
if __name__ == "__main__":
    here = sys.path[0]
    sys.path.insert(0, os.path.join(here, '..'))

#============================ imports =========================================

import time
import threading
import Tkinter
from Tkinter import Canvas
import ttk

import DC2321AConverters

from   dustUI                       import dustGuiLib, dustFrame, dustFrameText
from   dustUI.dustStyle             import dustStyle

#============================ defines =========================================

SYMBOL_DEGREE = u"\u2103"
PERCENT_SIGN  = u"\u0025"

DATA_TYPES = ['IC Status', 'Supply Voltage', 'Temperature', 'PRI Voltage', 'PRI Current', 'PRI Charge',
              'SEC Voltage', 'SEC Current', 'SEC Charge', 'Time', 'Mote Charge', 'ADC 0', 'ADC 1',
              'ADC 2', 'ADC 3', 'I2C Data', 'Increment']
              
TIME_UNITS = ['seconds', 'minutes', 'hours', 'days']
READ_WRITE = ['Read', 'Write']
TIME_CONVERSIONS = [1, 60, 3600, 86400]

MAC_ROW = 0
UNIT_ROW = 1
REQUEST_ROW = 2
DATA_ROW = 3
I2C_ADDR_ROW = 4
I2C_REG_ROW = 5
I2C_RW_ROW = 6
I2C_DATA_ROW = 7

DISPLAY_COL = 0
SPACE_1_COL = 1
BUTTON_COL = 2
AUTOSEND_CB_COL = 4
AUTOSEND_TB_COL = 5
SPACE_2_COL = 6
AUTOSEND_LIST_COL = 7

#============================ body ============================================

class DC2321AReportFrame(dustFrame.dustFrame):

    def __init__(self,
                parent,
                getValueCb,
                macAddr,
                frameName='Last Report',
                row=0,column=0):
        
        # record params
        self.parent           = parent
        self.getValueCb       = getValueCb
        self.macAddr          = macAddr
        self.value            = 0 
        self.unitLabel        = ''
        
        self.addrLabel        = None
        self.addrTextBox      = None
        
        # initialize parent
        dustFrame.dustFrame.__init__(self,
            parent.window,
            parent.guiLock,
            'Mote Report',
            row,column, False
        )
        self.grid(columnspan = 2)
        
        #-------------- CONFIGURE GRID
        
        #configure the dustFrame
        self.container.rowconfigure(0, pad=30)
        
        self.container.columnconfigure(DISPLAY_COL)
        self.container.columnconfigure(SPACE_1_COL, minsize=10)
        self.container.columnconfigure(BUTTON_COL, minsize=55) #minsize=120)
        self.container.columnconfigure(BUTTON_COL+1, minsize=65)
        self.container.columnconfigure(AUTOSEND_CB_COL)
        self.container.columnconfigure(AUTOSEND_TB_COL)
        self.container.columnconfigure(SPACE_2_COL, minsize=8)
        self.container.columnconfigure(AUTOSEND_LIST_COL, minsize=90)
        
        #-------------- INITIALIZE WIDGETS
        
        #add the MAC address at the top of the frame
        temp = dustGuiLib.Label(self.container,text = frameName)
        self._add(temp,MAC_ROW,DISPLAY_COL)
        temp.configure(
            font            = ("Helvetica",12,"bold"),  
            anchor          = Tkinter.CENTER
        )

        # unit label
        self.unitLabel = dustGuiLib.Label(self.container,text = u'Temperature (\u00b0C)') #unicode degree symbol
        self._add(self.unitLabel,UNIT_ROW,DISPLAY_COL)
        self.unitLabel.configure(
            font            = ("Helvetica",12,"bold"),  
            anchor          = Tkinter.CENTER
        )
        
        # data display
        self.valueMeter = dustGuiLib.Label(
            self.container,
            fg               = 'green',
            relief           = Tkinter.GROOVE, 
            borderwidth      = 2,
            width            = 7,
        )
        self._add(self.valueMeter,REQUEST_ROW,DISPLAY_COL)
        self.valueMeter.grid(rowspan=2)
        self.valueMeter.configure(
            font             = ('System', 40,'bold'),
            bg               = 'black',
        )

        # request data button
        self.requestDataButton = dustGuiLib.Button(self.container,
            text                  = 'Send Request',
            command               = self.requestDataButtonCB,
        )
        self._add(self.requestDataButton,REQUEST_ROW,BUTTON_COL)
        self.requestDataButton.grid(columnspan=2) #this is done for i2c labels
        
        
        # auto-send at interval check box
        self.repeatSend = Tkinter.StringVar()
        self.repeatSendCheckBox = Tkinter.Checkbutton(
            self.container,
            text = 'Auto-Send Every ',
            variable = self.repeatSend,
            onvalue=True,
            offvalue=False
        )
        self.repeatSend.set(False)
        self._add(self.repeatSendCheckBox,REQUEST_ROW,AUTOSEND_CB_COL)
        
        # auto-send interval text box
        self.repeatSendIntervalTextBox = dustGuiLib.Text(
            self.container,
            font=dustStyle.FONT_BODY,
            width=5,
            height=1,
        )
        self.repeatSendIntervalTextBox.insert(1.0,30)
        self._add(self.repeatSendIntervalTextBox,REQUEST_ROW,AUTOSEND_TB_COL)
        
        # auto-send interval unit list
        self.repeatIntervalUnit = Tkinter.StringVar()
        self.repeatIntervalUnitList = dustGuiLib.OptionMenu(
            self.container,
            self.repeatIntervalUnit,
            *TIME_UNITS
        )
        self.repeatIntervalUnit.set(TIME_UNITS[0])
        self._add(self.repeatIntervalUnitList,REQUEST_ROW,AUTOSEND_LIST_COL)
        
        # i2c address label
        self.addrLabel = dustGuiLib.Label(self.container, text=" Addr: 0x")
        self._add(self.addrLabel,I2C_ADDR_ROW,BUTTON_COL) #self._add(self.addrLabel,3,3)
        self.addrLabel.grid_remove()
        
        # i2c address text box
        self.addrTextBox = dustGuiLib.Text(
            self.container,
            font=dustStyle.FONT_BODY,
            width=5,
            height=1,
        )
        self._add(self.addrTextBox,I2C_ADDR_ROW,BUTTON_COL+1)
        self.addrTextBox.grid_remove()
        
        # i2c register label
        self.regLabel = dustGuiLib.Label(self.container, text="   Reg: 0x")
        self._add(self.regLabel,I2C_REG_ROW,BUTTON_COL) #self._add(self.addrLabel,3,3)
        self.regLabel.grid_remove()
        
        # i2c register text box
        self.regTextBox = dustGuiLib.Text(
            self.container,
            font=dustStyle.FONT_BODY,
            width=5,
            height=1,
        )
        self._add(self.regTextBox,I2C_REG_ROW,BUTTON_COL+1)
        self.regTextBox.grid_remove()
        
        # i2c data label
        self.dataLabel = dustGuiLib.Label(self.container, text=" # Bytes: ")
        self._add(self.dataLabel,I2C_DATA_ROW,BUTTON_COL) #self._add(self.addrLabel,3,3)
        self.dataLabel.grid_remove()
        
        # i2c data text box
        self.dataTextBox = dustGuiLib.Text(
            self.container,
            font=dustStyle.FONT_BODY,
            width=5,
            height=1,
        )
        self._add(self.dataTextBox,I2C_DATA_ROW,BUTTON_COL+1)
        self.dataTextBox.grid_remove()
        
        #-------------- INITIALIZE WIDGETS WITH TRACE CALLBACKS (do these last since they trigger on creation)
        
        # i2c read/write drop-down list
        self.readOrWrite = Tkinter.StringVar()
        self.readOrWriteList = dustGuiLib.OptionMenu(
            self.container,
            self.readOrWrite,
            *READ_WRITE
        )
        self.readOrWrite.trace("w", self.selectedReadOrWriteTypeCB)
        self.readOrWrite.set(READ_WRITE[0])
        self._add(self.readOrWriteList,I2C_RW_ROW,BUTTON_COL)
        self.readOrWriteList.grid(columnspan=2) #this is done for i2c labels
        self.readOrWriteList.grid_remove()
        
        # data type option menu
        self.selectedDataType = Tkinter.StringVar()
        self.dataTypeList = dustGuiLib.OptionMenu(
            self.container,
            self.selectedDataType,
            *DATA_TYPES
        )
        self.selectedDataType.trace("w", self.selectedDataTypeCB)
        self.selectedDataType.set(DATA_TYPES[2])
        self._add(self.dataTypeList,DATA_ROW,BUTTON_COL)
        self.dataTypeList.grid(columnspan=2) #this is done for i2c labels
        
        # schedule first GUI update
        self.updateGui(('', 0.0))
    

    #======================== FUNCTIONS ========================================

    def requestDataButtonCB(self):
        packet = [87, 0, 65] # 87 [W], 0 (don't send back GUI response), 65 [A]   ...
        shouldRepeat = int(self.repeatSend.get())
        if(shouldRepeat):
            packet.append(82) # 82 [R], repeat the send at the interval
        elif(False): # This function is disabled to simplify GUI controls. Just Request Data with 'Auto-Send' unchecked.
            packet.append(83) # 83 [S], stop sending at an interval
        else:
            packet.append(78) # 78 [N], do not repeat the send
        
        packet.append(DATA_TYPES.index(self.selectedDataType.get()))
        
        if(DATA_TYPES.index(self.selectedDataType.get()) == 15):
            if(READ_WRITE.index(self.readOrWrite.get()) == 0): #read
                packet.append(int(self.addrTextBox.get(1.0,Tkinter.END),16)) #read as hex
                packet.append(len(self.regTextBox.get(1.0,Tkinter.END))/2)
                packet.extend((0,0,0))
                packet.append(int(self.regTextBox.get(1.0,Tkinter.END),16))
                packet.append(int(self.dataTextBox.get(1.0,Tkinter.END)))
            else: #write
                packet = [87, 0, 73] # 87 [W], 0 (don't send back GUI response), 73 [I] (i2c write)
                packet.append(int(self.addrTextBox.get(1.0,Tkinter.END),16))
                packet.append((len(self.dataTextBox.get(1.0,Tkinter.END))/2) + 1) #add 1 to include register byte
                packet.append(int(self.regTextBox.get(1.0,Tkinter.END),16))
                dataString = self.dataTextBox.get(1.0,Tkinter.END)
                dataString = dataString[:len(dataString)-1] #remove newline character
                packet.extend(self.hexStringToByteArray(dataString))
                self.parent._sendData(self.macAddr, packet)
                return
        
        if(shouldRepeat):
            timeConversionIndex = TIME_UNITS.index(self.repeatIntervalUnit.get())
            repeatInterval = int(self.repeatSendIntervalTextBox.get(1.0,Tkinter.END).strip())
            repeatInterval = repeatInterval * TIME_CONVERSIONS[timeConversionIndex]
            repeatInterval = self.int32ToByteTuple(repeatInterval)
            packet.extend(repeatInterval)
        
        self.parent._sendData(self.macAddr, packet)
        return
    
    
    def selectedDataTypeCB(self, *args):
        if(DATA_TYPES.index(self.selectedDataType.get()) == 15):
            self.addrLabel.grid()
            self.addrTextBox.grid()
            self.regLabel.grid()
            self.regTextBox.grid()
            self.readOrWriteList.grid()
            self.dataLabel.grid()
            self.dataTextBox.grid()
        else:
            self.addrLabel.grid_remove()
            self.addrTextBox.grid_remove()
            self.regLabel.grid_remove()
            self.regTextBox.grid_remove()
            self.readOrWriteList.grid_remove()
            self.dataLabel.grid_remove()
            self.dataTextBox.grid_remove()
    
    def selectedReadOrWriteTypeCB(self, *args):
        if(READ_WRITE.index(self.readOrWrite.get()) == 0): #read
            self.dataLabel.configure(text=" # Bytes: ")
            self.dataTextBox.delete(1.0,Tkinter.END)
            self.repeatSendCheckBox.config(state='normal')
        else:
            self.dataLabel.configure(text=" Data: 0x")
            self.dataTextBox.delete(1.0,Tkinter.END)
            self.repeatSendCheckBox.config(state='disabled')
            self.repeatSendCheckBox.deselect()
    
    def hexStringToByteArray(self, hexString):
        if len(hexString) % 2 == 1: hexString = '0' + hexString
        return bytearray.fromhex(hexString)
    
    def int32ToByteTuple(self, integer):
        byteTuple = (
            integer >> 24,
            (integer >> 16) & 0xFF,
            (integer >> 8) & 0xFF,
            integer & 0xFF
        )
        return byteTuple
    
    def updateGui(self, data):
        self.unitLabel.configure(
            text = data[0]
        )
        
        meterText = ''
        if(data[0] == "IC Status"):
            noYes = [' NO ', 'YES']
            icStatus = data[1]
            meterText =  '________  PGOOD     EH_ON \n'
            meterText += 'LTC3106:     ' + noYes[((icStatus >> 7) & 1)] + '          ' + '   -   ' + '   \n'
            meterText += 'LTC3107:     ' + noYes[((icStatus >> 6) & 1)] + '          ' + noYes[((icStatus >> 2) & 1)] + '   \n'
            meterText += 'LTC3330:     ' + noYes[((icStatus >> 5) & 1)] + '          ' + noYes[((icStatus >> 1) & 1)] + '   \n'
            meterText += 'LTC3331:     ' + noYes[((icStatus >> 4) & 1)] + '          ' + noYes[(icStatus & 1)] + '   '
            
            self.valueMeter.configure(
            font = ('System', 12,'bold'),
            text = meterText,
            )
            return
        
        if(data[0] == "I2C Data"):
            meterText = format(data[1], 'X')
            if len(meterText) % 2 != 0: meterText = '0' + meterText #pad zero if necessary
            meterText = '0x' + meterText
            
            self.valueMeter.configure(
            font = ('System', 36,'bold'),
            text = meterText,
            )
            return
        
        if(type(data[1]) is float):
            meterText = '{0:.2f}'.format(data[1])
        else:
            meterText = data[1]
        
        self.valueMeter.configure(
            font = ('System', 40,'bold'),
            text = meterText
        )




/**
Copyright (c) 2016, Dust Networks.  All rights reserved.

This file manages communication with ADI's ADT75 temperature sensor.

Note: the program must be restarted if the sensor board is attached during operation (due to initialization).

*/
#include <stdlib.h>
#include <string.h>
#include "loc_task.h"
#include "dn_system.h"

#include "temperature_sensor.h"
#include "devices.h"
#include "coulomb_counter.h"

//=========================== defines =========================================


//=========================== const ======================================
const INT8U ts_set_config[] = {TS_REG_CONFIG, TS_COM_ONE_SHOT};
const INT8U ts_set_one_shot_read[] = {TS_REG_ONE_SHOT};

//=========================== variables =======================================

void temperatureSensorInit() //put the temp sensor into shutdown mode
{
  I2CWrite(&ts_set_config, TS_ADDRESS, sizeof(ts_set_config));
}
                  
INT16U readTemperatureSensor()
{ 
  I2CWrite(&ts_set_one_shot_read, TS_ADDRESS, sizeof(ts_set_one_shot_read));
  
  OSTimeDly(60); //delay to give sensor time to take one-shot measurement
  
  INT16U temperatureData = 0;
  INT8U temperatureReg = TS_REG_TEMPERATURE;
  I2CWriteAndRead(TS_ADDRESS, &temperatureReg, sizeof(temperatureReg), &temperatureData, sizeof(temperatureData));

  //flip bytes
  temperatureData = (temperatureData << 4) | (temperatureData >> 12); //four LSBs are not used, so shifts account for that
  //now 'temperature' represents the temperature in 0.0625 degC
  
  dnm_ucli_printf("Temperature: 0x%02x\r\n", temperatureData);
  
  return temperatureData;
}

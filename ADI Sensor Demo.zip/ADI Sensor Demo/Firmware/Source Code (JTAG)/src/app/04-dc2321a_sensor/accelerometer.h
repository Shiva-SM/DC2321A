/*
Copyright (c) 2016, Dust Networks.  All rights reserved.
*/

#ifndef ACCELEROMETER_H
#define ACCELEROMETER_H

#include "app_task_cfg.h"
#include "dn_typedef.h"
#include "loc_task.h"
#include "cli_task.h"
#include "dc2321a.h"
#include "cog_driver.h"
#include "dn_spi.h"

//=========================== defines =========================================

typedef enum {ACCEL_DATA_X, ACCEL_DATA_Y, ACCEL_DATA_Z} accelerometer_data_t;

// Pins
#define ACCEL_CS                SENSOR_BOARD_ID_0

// Commands
#define ACCEL_COM_WRITE       0x0A
#define ACCEL_COM_READ        0x0B

// Registers
#define ACCEL_REG_AD          0x00
#define ACCEL_REG_POWER_CTL   0x2D

//=========================== structs =========================================


//=========================== global variables ================================


//=========================== prototypes ======================================
void testAccelerometer();
void accelerometerInit();
extern INT8U* readAccelerometer();
//INT16U readAccelerometer();

#endif 

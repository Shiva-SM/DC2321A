/*
Copyright (c) 2016, Dust Networks.  All rights reserved.
*/

#ifndef TEMPERATURE_SENSOR_H
#define TEMPERATURE_SENSOR_H

#include "app_task_cfg.h"
#include "dn_typedef.h"
#include "loc_task.h"
#include "cli_task.h"


//=========================== defines =========================================
// Addressses
#define TS_ADDRESS            0x48

#define TS_REG_TEMPERATURE    0x00
#define TS_REG_CONFIG         0x01
#define TS_REG_ONE_SHOT       0x04

// Commands
#define TS_COM_ONE_SHOT       0x20

//=========================== structs =========================================


//=========================== global variables ================================


//=========================== prototypes ======================================
void temperatureSensorInit();
INT16U readTemperatureSensor();

#endif 

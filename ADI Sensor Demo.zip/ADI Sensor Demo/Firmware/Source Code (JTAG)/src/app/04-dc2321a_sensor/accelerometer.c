/**
Copyright (c) 2016, Dust Networks.  All rights reserved.

This file manages communication with ADI's ADT75 temperature sensor.

Note: the program must be restarted if the sensor board is attached during operation (due to initialization).

*/
#include <stdlib.h>
#include <string.h>
#include "loc_task.h"
#include "dn_system.h"

#include "accelerometer.h"
#include "devices.h"

//=========================== defines =========================================

//=========================== prototypes =========================================
void setMeasurementMode();
INT8S rawByteToAngleByte(INT8U rawData);
INT16S rawDataToAngleData(INT16U rawData);

//=========================== const ======================================
const INT8U readAccelerometerCom[] = {ACCEL_COM_READ, 0x0E, 0, 0, 0, 0, 0, 0};
const INT8U readAccelerometerShortCom[] = {ACCEL_COM_READ, 0x08, 0, 0, 0};
//=========================== variables =======================================

void accelerometerInit() //repurpose GPIO 3 to serve as a /SS
{
   configGPIO(ACCEL_CS, GPIO_STATE_OUTPUT);
   digitalWrite(ACCEL_CS, GPIO_OUTPUT_HIGH);
   
   //SPI is not yet initialized at this point
}

void setMeasurementMode()
{
   INT8U bytesToSend[] = {ACCEL_COM_WRITE, ACCEL_REG_POWER_CTL, 0x02};
   digitalWrite(ACCEL_CS, GPIO_OUTPUT_LOW);
   spiSendAndReceiveBuffer(bytesToSend, sizeof(bytesToSend));
   digitalWrite(ACCEL_CS, GPIO_OUTPUT_HIGH);
}

INT8U* readAccelerometer()
{
  setMeasurementMode();
   
   digitalWrite(ACCEL_CS, GPIO_OUTPUT_LOW);
   INT8U* receivedData = spiSendAndReceiveBuffer(readAccelerometerShortCom, sizeof(readAccelerometerShortCom));
   digitalWrite(ACCEL_CS, GPIO_OUTPUT_HIGH);
   
   INT8U accelerometerData[] = {receivedData[2], receivedData[3], receivedData[4]};

   return accelerometerData;
}

INT8S rawByteToAngleByte(INT8U rawData)
{
   INT8U isNegative = (rawData >> 7);
   INT8S magnitude = (INT8S)(rawData & 0x7F);
   INT8S result = magnitude > 0x3F ? 0x7F - magnitude: magnitude;
   return isNegative ? -result : result;
}

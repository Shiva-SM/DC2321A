/**
Copyright (c) 2016, Dust Networks.  All rights reserved.

This file manages communication with ADI's ADT75 temperature sensor.

Note: the program must be restarted if the sensor board is attached during operation (due to initialization).

*/
#include <stdlib.h>
#include <string.h>
#include "loc_task.h"
#include "dn_system.h"

#include "dc2321a.h"
#include "light_sensor.h"
#include "devices.h"

#include <math.h>

//=========================== defines =========================================

//=========================== const ======================================

//=========================== variables =======================================

//=========================== prototypes =========================================

INT16U convertMillivoltsToLux(INT16U mvData);


// Read the light sensor
// In case of fluxuations, allow user to set a number of measurement iterations
// and the delay time (ms) between them. The measurements are then averaged.
INT16U readLightSensor(INT8U iterations, INT8U iterationDelay)
{ 
  digitalWrite(SENSOR_BOARD_IO, 1); //turn on the light sensor
  OSTimeDly(1); //wait for the voltage to settle
  
  INT32U adcValSum = 0;
  for(INT8U i = 0; i < iterations; i++)
  {
     OSTimeDly(iterationDelay); //wait for the voltage to settle
     adcValSum += (INT32U)readADC(0); //take a reading 
  }
  
  digitalWrite(SENSOR_BOARD_IO, 0); //turn off the light sensor
  INT16U adcVal = (INT16U)(adcValSum / iterations / 10); //(divide by 10 so it is in mV)
 
  return convertMillivoltsToLux(adcVal);
}

INT16U convertMillivoltsToLux(INT16U mvData)
{
  return (INT16U)(6.9913*powf(mvData, 0.7324)); //equation comes from a line of best fit based on empirical data
}

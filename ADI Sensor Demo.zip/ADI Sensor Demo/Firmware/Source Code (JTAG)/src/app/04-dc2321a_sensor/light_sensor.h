/*
Copyright (c) 2016, Dust Networks.  All rights reserved.
*/

#ifndef TEMPERATURE_SENSOR_H
#define TEMPERATURE_SENSOR_H

#include "app_task_cfg.h"
#include "dn_typedef.h"
#include "loc_task.h"
#include "cli_task.h"


//=========================== defines =========================================

#define LS_CLIP_LOW 0x00
#define LS_CLIP_HIGH 0xFF

//=========================== structs =========================================


//=========================== global variables ================================


//=========================== prototypes ======================================
extern INT16U readLightSensor(INT8U iterations, INT8U iterationDelay);

#endif 

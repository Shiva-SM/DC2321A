import logging
import struct
class NullHandler(logging.Handler):
    def emit(self, record):
        pass
log = logging.getLogger('DC2321ASensorConverters')
log.setLevel(logging.ERROR)
log.addHandler(NullHandler())

dataLabels = (
    (u'Temperature (\u00b0C)',),
    ('Illuminance (Lux)',),
    ('Proximity (mm)',),
    ('Angle (normalized)', 'X', 'Y', 'Z'),
    );
    
dataScalers = (
    16, #temperature
    -1, #light, no conversion needed
    -1, #proximity
    -1, #angle
    );
    
forcedYAxisExtrema = ( # [0] = is it forced?,  [1] = forced y min,  [2] = forced y max
    (False,), #temperature
    (False,), #light, no conversion needed
    (False,), #proximity
    (True, -1, 1), #angle
    );
    
class DataSet(object):
    
    def __init__(self, type, values):
        self.type = type
        self.values = values
        
    
class DC2321ASensorConverters(object):
    #======================== singleton pattern ===============================
    
    _instance           = None
    _init               = False
    
    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super(DC2321ASensorConverters,cls).__new__(cls, *args, **kwargs)
        return cls._instance
    
    def __init__(self):
        
        # don't re-initialize an instance (needed because singleton)
        if self._init:
            return
        self._init = True
        
        # log
        log.info("creating instance")
    
    #======================== public ==========================================
    
    def convertData(self,byteArray): #get the type of data sent and return the data properly scaled
        dataSetList = list()
        
        index = 0
        while(index < len(byteArray)):
            currentDataType = (tuple(byteArray)[index]); index += 1
            currentDataValues = list()
            if currentDataType == 0: #temperature
                tempDataVal = self.byteTupleToInt(byteArray[index:index+2]); index += 2
                tempDataVal = float(tempDataVal) / dataScalers[currentDataType]
                currentDataValues.append(tempDataVal)
            elif (currentDataType == 1): #light data
                tempDataVal = self.byteTupleToInt(byteArray[index:index+2]); index += 2
                currentDataValues.append(tempDataVal)
            elif (currentDataType == 3): #accelerometer data
                x = self.rawAngleByteToNormalizedFloat(byteArray[1])
                y = self.rawAngleByteToNormalizedFloat(byteArray[2])
                z = self.rawAngleByteToNormalizedFloat(byteArray[3])
                currentDataValues.append(x)
                currentDataValues.append(y)
                currentDataValues.append(z)
                index += 3
            dataSetList.append(DataSet(currentDataType, currentDataValues))
            
        return dataSetList
        
        
    def _toString(self, byteArray):
        return ''.join([chr(b) for b in byteArray])
        
    def byteTupleToInt(self, byteArray): #16-bit
        return (byteArray[0] << 8) + byteArray[1]
        
    def byteTupleToLong(self, byteArray): #32-bit
        return (byteArray[0] << 24) + (byteArray[1] << 16) + (byteArray[2] << 8) + byteArray[3]
        
    def rawAngleByteToNormalizedFloat(self, byte):
        result = byte & 0x7F
        
        if(result > 0x3F):
            result = 0x7F - result
        
        if(byte & 0x80 != 0):
            result = -result;
        
        return float(result) / 63

#============================ main ============================================

def main():
    pass

if __name__ == '__main__':
	main()
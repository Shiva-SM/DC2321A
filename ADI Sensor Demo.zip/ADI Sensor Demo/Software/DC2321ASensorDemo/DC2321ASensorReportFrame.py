#============================ adjust path =====================================

import sys
import os
if __name__ == "__main__":
    here = sys.path[0]
    sys.path.insert(0, os.path.join(here, '..', '..','libs'))

#============================ imports =========================================

import time
import threading
import Tkinter
from Tkinter import *
import ttk

import DC2321ASensorConverters

from   dustUI                       import dustGuiLib, dustFrame, dustFrameText
from   dustUI.dustStyle             import dustStyle

# graph setup:
# http://matplotlib.org/examples/user_interfaces/embedding_in_tk2.html

import matplotlib
matplotlib.use('TkAgg')
from numpy import arange
import numpy as np
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2TkAgg
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.pylab as p

#============================ defines =========================================

SYMBOL_DEGREE = u"\u2103"
PERCENT_SIGN  = u"\u0025"

ROW_MAC = 0
ROW_UNIT = 1
ROW_SPACE_1 = 2
ROW_LAST_MEAS = 3
ROW_METER = 4
ROW_METER2 = 5
ROW_METER3 = 6
ROW_SPACE_2 = 7
ROW_REQUEST_BTN = 8
ROW_AUTO_SEND = 9
COL_GRAPH = 0
COL_SPACE = 1
COL_METER = 2
COL_AUTO_SEND_CHECKBOX = 2
COL_AUTO_SEND_TEXTBOX = 3
COL_AUTO_SEND_SPACE = 4
COL_AUTO_SEND_LIST = 5

COL_METER_SPAN = 40

TIME_UNITS = ['seconds', 'minutes', 'hours', 'days']
TIME_CONVERSIONS = [1, 60, 3600, 86400]

#============================ body ============================================

class DC2321ASensorReportFrame(dustFrame.dustFrame):
    
    def __init__(self,
                parent,
                getValueCb,
                macAddr,
                frameName='Last Report',
                row=0,column=0):
        
        # record params
        self.parent           = parent
        self.getValueCb       = getValueCb
        self.macAddr          = macAddr
        self.value            = 0 
        
        self.dataTypeIndex    = -1
        
        self.maxNumDataPoints  = 20
        self.currentXData      = []
        self.currentYData      = []
        self.line              = None
        self.lastYData         = [] #can be up to 3 values, one for each axis
        self.axisYMin          = 20
        self.axisYMax          = 30
        
        #for 3-axis accelerometer
        self.currentYData2     = []
        self.currentYData3     = []
        self.line2             = None
        self.line3             = None
        
        # initialize parent
        dustFrame.dustFrame.__init__(self,
            parent.window,
            parent.guiLock,
            'Mote Report',
            row,column, False
        )
        self.grid(columnspan = 2)
        
        #configure the dustFrame
        self.container.rowconfigure(ROW_SPACE_1, minsize = 10)
        self.container.rowconfigure(ROW_SPACE_2, minsize = 10)
        
        self.container.columnconfigure(COL_GRAPH)
        self.container.columnconfigure(COL_SPACE, minsize = 15)
        self.container.columnconfigure(COL_AUTO_SEND_SPACE, minsize = 10)
        
        #add the MAC address at the top of the frame
        macLabel = dustGuiLib.Label(self.container,text = frameName)
        self._add(macLabel,ROW_MAC,COL_METER)
        macLabel.grid(columnspan = COL_METER_SPAN)
        macLabel.configure(
            font            = ("Helvetica",12,"bold"),  
            anchor          = Tkinter.CENTER
        )
        
        
        
        #unit label
        self.unitLabelVar = StringVar()
        self.unitLabel = self.createLabelVar(self.unitLabelVar, ROW_UNIT, COL_METER)
        self.unitLabel.grid(columnspan = COL_METER_SPAN)
        
        #last measurement label
        self.lastMeasurementLabel = self.createLabel('Last Measurement:', ROW_LAST_MEAS, COL_METER)
        self.lastMeasurementLabel.grid(columnspan = COL_METER_SPAN)
        
        #value meter
        self.valueMeter = self.createValueMeter(ROW_METER, COL_METER)
        self.valueMeter.grid(columnspan = COL_METER_SPAN)
        
         # request data button
        self.requestDataButton = dustGuiLib.Button(self.container,
            text                  = 'Request Data',
            command               = self.requestDataButtonCB,
        )
        self._add(self.requestDataButton,ROW_REQUEST_BTN,COL_METER)
        self.requestDataButton.grid(columnspan = COL_METER_SPAN)
        
        
        # auto-send at interval check box
        self.repeatSend = Tkinter.StringVar()
        self.repeatSendCheckBox = Tkinter.Checkbutton(
            self.container,
            text = 'Auto-Send Every ',
            variable = self.repeatSend,
            onvalue=True,
            offvalue=False
        )
        self.repeatSend.set(False)
        self._add(self.repeatSendCheckBox,ROW_AUTO_SEND,COL_AUTO_SEND_CHECKBOX)
        
        # auto-send interval text box
        self.repeatSendIntervalTextBox = dustGuiLib.Text(
            self.container,
            font=dustStyle.FONT_BODY,
            width=5,
            height=1,
        )
        self.repeatSendIntervalTextBox.insert(1.0,30)
        self._add(self.repeatSendIntervalTextBox,ROW_AUTO_SEND,COL_AUTO_SEND_TEXTBOX)
        
        # auto-send interval unit list
        self.repeatIntervalUnit = Tkinter.StringVar()
        self.repeatIntervalUnitList = dustGuiLib.OptionMenu(
            self.container,
            self.repeatIntervalUnit,
            *TIME_UNITS
        )
        self.repeatIntervalUnit.set(TIME_UNITS[0])
        self._add(self.repeatIntervalUnitList,ROW_AUTO_SEND,COL_AUTO_SEND_LIST)
        
        
        #GRAPH SETUP
        self.graphStartTime = time.time()
        
        #setup figure and subplots
        fig = plt.Figure(figsize = (4.5, 3))
        self.axes = fig.add_subplot(111)

        #adjust to be able to view axes titles
        fig.subplots_adjust(bottom = .2, left = .2, top = .85)
        
        #set axis and graph titles
        self.axes.set_title("???")
        self.axes.set_xlabel("Time (s)")
        self.axes.set_ylabel("??? (?)")
        
        self.axes.yaxis.grid()
        self.axes.xaxis.grid()
        
        #plot data
        self.line, = self.axes.plot(self.currentXData, self.currentYData, 'b-')
        self.line2, = self.axes.plot(self.currentXData, self.currentYData2, 'r-')
        self.line3, = self.axes.plot(self.currentXData, self.currentYData3, 'g-')
        
        #set up animation 
        self.canvas = FigureCanvasTkAgg(fig, master=self.container)
        self.canvas.get_tk_widget().grid(column=0, row=0, rowspan = 10)
        self.canvas._tkcanvas.config(highlightthickness = 0)
        plt.show()

        self.setDataType(0)
    
    #======================== public ==========================================
    
    #======================== private ========================================
    
    def requestDataButtonCB(self):
        packet = [87, 0, 65] # 87 [W], 0 (don't send back GUI response), 65 [A]   ...
        
        shouldRepeat = int(self.repeatSend.get())
        if(shouldRepeat):
           packet.append(82) # 82 [R], repeat the send at the interval
        elif(False): # This function is disabled to simplify GUI controls. Just Request Data with 'Auto-Send' unchecked.
           packet.append(83) # 83 [S], stop sending at an interval
        else:
           packet.append(78) # 78 [N], do not repeat the send
        
        packet.append(17) # this is the ID of the SENSOR data type
        
        if(shouldRepeat):
            timeConversionIndex = TIME_UNITS.index(self.repeatIntervalUnit.get())
            repeatInterval = int(self.repeatSendIntervalTextBox.get(1.0,Tkinter.END).strip())
            repeatInterval = repeatInterval * TIME_CONVERSIONS[timeConversionIndex]
            repeatInterval = self.int32ToByteTuple(repeatInterval)
            packet.extend(repeatInterval)
        
        self.parent._sendData(self.macAddr, packet)
        return
        
    def int32ToByteTuple(self, integer):
        byteTuple = (
            integer >> 24,
            (integer >> 16) & 0xFF,
            (integer >> 8) & 0xFF,
            integer & 0xFF
        )
        return byteTuple
        
    def setDataType(self, typeIndex):
        self.dataTypeIndex = typeIndex
        newText = DC2321ASensorConverters.dataLabels[typeIndex][0]
        self.unitLabelVar.set(newText)
        self.axes.set_ylabel(newText)
        self.axes.set_title(newText.rsplit(' ', 1)[0] + ' vs Time')
    
    def createLabel(self, labelText, row, col):
        label = dustGuiLib.Label(self.container,text = labelText) #unicode degree symbol
        self._add(label,row,col)
        label.configure(
            font            = ("Helvetica",12,"bold"),  
            anchor          = Tkinter.CENTER
        )
        return label
        
    def createLabelVar(self, labelVar, row, col):
        label = Label(self.container,textvariable = labelVar) #unicode degree symbol
        self._add(label,row,col)
        label.configure(
            font            = ("Helvetica",12,"bold"),  
            anchor          = Tkinter.CENTER
        )
        return label
    
    def createValueMeter(self, row, col):
        valueMeter = dustGuiLib.Label(
            self.container,
            fg               = 'green',
            relief           = Tkinter.GROOVE, 
            borderwidth      = 2,
            width            = 6,
        )
        self._add(valueMeter,row,col)
        
        valueMeter.configure(
            font             = ('System', 40,'bold'),
            bg               = 'black',
        )
        return valueMeter
    
    def updateGui(self, dataSet):
        for data in dataSet:
            dataType = data.type
            self.setDataType(dataType)
            if(dataType == 0): #temperature sensor
                self.lastYData = data.values
                self.valueMeter.configure(text = '{0:.2f}'.format(self.lastYData[0]),)
            elif(dataType == 1): #light sensor
                self.lastYData = data.values
                self.valueMeter.configure(text = self.lastYData[0])
            elif(dataType == 3): #accelerometer
                self.lastYData = data.values
                xSpace = ' '
                ySpace = ' '
                zSpace = ' '
                if(data.values[0] < 0): xSpace = ''
                if(data.values[1] < 0): ySpace = ''
                if(data.values[2] < 0): zSpace = ''
                valueString = 'BLUE:            x = ' + xSpace + '{0:.3f}'.format(data.values[0]) + '                    ' +\
                '\nRED:              y = ' + ySpace + '{0:.3f}'.format(data.values[1]) + '                    ' +\
                '\nGREEN:         z = ' + zSpace + '{0:.3f}'.format(data.values[2]) + '                    '
                self.valueMeter.configure(font = ('System', 16,'bold'), text = valueString)
            self.updateGraph()
            self.blinkValueMeter()
        
    def updateGraph(self):
        if(len(self.currentXData) >= self.maxNumDataPoints): # we are at the data point limit, discard the first data point
            self.currentXData.pop(0)
            self.currentYData.pop(0)
            if(len(self.currentYData2) > 0): self.currentYData2.pop(0)
            if(len(self.currentYData3) > 0): self.currentYData3.pop(0)
        
        elapsedTime = time.time() - self.graphStartTime
        self.currentXData.append(elapsedTime)
        self.currentYData.append(self.lastYData[0])

        self.axes.hold(False)
        self.line.set_xdata(self.currentXData)
        self.line.set_ydata(self.currentYData)
        
        axisYMax = max(self.currentYData)
        axisYMin = min(self.currentYData)
        
        # 3-axis accelerometer
        if(len(self.lastYData) > 1):
            self.currentYData2.append(self.lastYData[1])
            self.line2.set_xdata(self.currentXData)
            self.line2.set_ydata(self.currentYData2)
            axisYMax = max(axisYMax, max(self.currentYData2))
            axisYMin = min(axisYMin, min(self.currentYData2))
            
        if(len(self.lastYData) > 2):
            self.currentYData3.append(self.lastYData[2])
            self.line3.set_xdata(self.currentXData)
            self.line3.set_ydata(self.currentYData3)
            axisYMax = max(axisYMax, max(self.currentYData3))
            axisYMin = min(axisYMin, min(self.currentYData3))
        
        axisYMax = np.ceil(axisYMax)
        axisYMin = np.floor(axisYMin)
        if(DC2321ASensorConverters.forcedYAxisExtrema[self.dataTypeIndex][0]): #check if the y axis is forced to values
            axisYMax = DC2321ASensorConverters.forcedYAxisExtrema[self.dataTypeIndex][2]
            axisYMin = DC2321ASensorConverters.forcedYAxisExtrema[self.dataTypeIndex][1]
        if(axisYMax - axisYMin < 1):
            axisYMax = axisYMin + 1
        yBuffer = float(axisYMax - axisYMin) / 20
        self.axes.set_ylim(axisYMin - yBuffer, axisYMax + yBuffer)
        
        axisXMax = max(self.currentXData)
        axisXMin = min(self.currentXData)
        if(axisXMax - axisXMin < 5):
            axisXMax = axisXMin + 5
        self.axes.set_xlim(axisXMin, axisXMax)
        
        self.canvas.draw()
        self.canvas.flush_events()
    
    def blinkValueMeter(self):
        if(self.valueMeter.cget("fg") == 'green'):
            self.valueMeter.configure(fg = 'black')
            self.after(100,self.blinkValueMeter)
        else:
            self.valueMeter.configure(fg = 'green')
        
        
#============================ imports =========================================
from collections                                 import deque
import threading

#============================ body ============================================

class moteData(object):

    def __init__(self, macAddress, moteNumber):        
        self.macAddress         = macAddress
        self.value              = 0, 0.0
        self.dataLock           = threading.RLock()
        self.moteNumber         = moteNumber


    #======================== public ==========================================
    def getAddress(self):
        with self.dataLock:
            return self.macAddress

    def getAddressString(self):
        with self.dataLock:
            str = "("
            for i in range(len(self.macAddress)):
                temp = format(self.macAddress[i], 'x')
                if len(temp)==1:
                    temp = '0'+temp
                if i != 0 & i != len(self.macAddress)-1:
                    str += "-"
                str += temp
            str += ")"
            return str

    def setValue(self,value):
        with self.dataLock:
            self.value = value

    def getValue(self):
        with self.dataLock:
            return self.value

    def getMoteNumber(self):
        with self.dataLock:
            return self.moteNumber
            
    def toString(self):
        if len(self.value) == 0:
            return str(self.macAddress) + ' has no data associated yet.'
        else:
            lastValue = list(self.value)[0]
            return str(self.macAddress) + ' has (charge,current) of (' + str(lastValue)+ ', ' + str(self.charge) + ').\n'


#============================ main ============================================

def main():
    motedata = moteData((0,1,0,0,0,3,3,2))
    print str(list(motedata.getValue()))
    for x in range (0, 15):
        motedata.setValue(x / 15.0 )
    print motedata.toString()

if __name__ == '__main__':
    main()